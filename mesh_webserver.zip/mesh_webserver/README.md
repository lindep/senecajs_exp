
Access via curl

curl -v 'http://localhost:3000/api/calculate/sum?left=2&right=3'
