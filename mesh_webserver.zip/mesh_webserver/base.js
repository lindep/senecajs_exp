require('seneca')()
  .use('mesh',{base:true, tag:'base'})
