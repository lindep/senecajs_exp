require( 'seneca' )({ strict: { find: false } })
  .use( 'math' )
  .use('mesh', { base:true, auto:true, pin:'role:math' })
  //.listen({ type: 'tcp', pin: 'role:math' })
